const express = require('express')
const path = require('path')

const shopController = require('../controllers/shop')

const router = express.Router()

router.get('/', shopController.getIndex)

module.exports = router;