const { Sequelize } = require('sequelize');
// replace 'jvwf7013' with password of your local mysql database
const sequelize = new Sequelize('node-complete', 'root', 'jvwf7013', {
  dialect: 'mysql',
  host: 'localhost'
})

module.exports = sequelize;